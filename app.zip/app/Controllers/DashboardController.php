<?php

namespace App\Controllers;

use App\Models\TransactionModel;
use App\Models\UserModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $transactionModel = new TransactionModel();
        $userModel = new UserModel();

        // Fetch monthly data
        $currentMonth = date('m');
        $currentYear = date('Y');
        $monthlyTransactions = $transactionModel->where('MONTH(created_at)', $currentMonth)->where('YEAR(created_at)', $currentYear)->countAllResults();
        $monthlyEarnings = $transactionModel->where('MONTH(created_at)', $currentMonth)->where('YEAR(created_at)', $currentYear)->selectSum('total_harga')->first()['total_harga'];
        $monthlyUsers = $userModel->where('MONTH(created_at)', $currentMonth)->where('YEAR(created_at)', $currentYear)->countAllResults();

        // Fetch annual data
        $annualTransactions = $transactionModel->where('YEAR(created_at)', $currentYear)->countAllResults();
        $annualEarnings = $transactionModel->where('YEAR(created_at)', $currentYear)->selectSum('total_harga')->first()['total_harga'];
        $annualUsers = $userModel->where('YEAR(created_at)', $currentYear)->countAllResults();

        $data = [
            'monthlyTransactions' => $monthlyTransactions,
            'monthlyEarnings' => $monthlyEarnings,
            'monthlyUsers' => $monthlyUsers,
            'annualTransactions' => $annualTransactions,
            'annualEarnings' => $annualEarnings,
            'annualUsers' => $annualUsers
        ];

        return view('dashboard', $data);
    }
}
